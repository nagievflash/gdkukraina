<?php
/**
 * The header.
 *
 * This is the template that displays all of the <head> section and everything up until main.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>
<!doctype html>
<head>
		<meta charset="UTF-8" />
		<title>Муниципальное бюджетное клубное учреждение «Городской Дом Культуры «Украина», кино, мероприятия, концертный зал, афиша, праздники</title>
		<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
		<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
		<meta name="format-detection" content="telephone=no" />
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0" />
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
		<meta name="theme-color" content="#D8232A" />
		<link rel="icon" type="image/png" sizes="48x48" href="<?php echo get_template_directory_uri(); ?>/assets/images/favicon.ico" />
		<meta name="yandex-verification" content="c344716fb1efb442" />
		<script>
		setTimeout(function()
		{
		document.getElementsByTagName('html')[0].classList.add('_is-preloaded');
		}, 10000);
		</script>
		<meta property="og:type" content="website" />
		<meta property="og:url" content="https://gdkukraina.ru/" />
		<meta property="og:title" content="Муниципальное бюджетное клубное учреждение «Городской Дом Культуры «Украина»" />
		<meta property="og:description" content="Муниципальное бюджетное клубное учреждение «Городской Дом Культуры «Украина», кино, мероприятия, концертный зал, афиша, праздники" />
		<meta property="og:image" content="<?php echo get_template_directory_uri(); ?>/assets/images/logo_new-1.png" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta name="description" content="Официальный сайт Муниципального учреждения Городской Дом культуры «Украина»" />
		<!-- <script type="text/javascript">
		    var _ba = _ba || [];
		    _ba.push(["aid", "f30e19884dead8521e23efbba5cc78b6"]);
		    _ba.push(["host", "www.russiancrab.ru"]);
		    (function () {
		        var ba = document.createElement("script");
		        ba.type = "text/javascript";
		        ba.async = true;
		        ba.src = (document.location.protocol == "https:" ? "https://" : "http://") + "bitrix.info/ba.js";
		        var s = document.getElementsByTagName("script")[0];
		        s.parentNode.insertBefore(ba, s);
		    })();
		</script> -->
</head>
<body>
	<div class="wrap-page">
		<div class="header">
	    <div class="wrap-wide header__inner">
	        <span class="logo" href="/">
	            <span>Главная страница</span>
	        </span>
	        <button class="header__burger js-burger">
	            <span>Menu</span>
	        </button>
	        <nav class="header__nav">
	            <ul class="header__nav-list">
	                <li><a href="">Главная</a></li>
	                <li><a href="#">Купить Билеты</a></li>
	                <li><a href="#">Об Учреждении</a></li>
	                <li><a href="#">Кинозал</a></li>
	                <li><a href="#">Противодействие коррупции</a></li>
	                <li><a href="news">Новости</a></li>
	                <li><a href="#">Сведения о доходах</a></li>
	                <li><a href="contacts">Контакты</a></li>
	            </ul>
	        </nav>
	        <div class="header__right">
	            <div class="header__lang-switcher">

	                <div class="header__lang-dropdown js-lang-dropdown">
	                    <div class="header__lang-dropdown-title title-h1">Select your preferred language</div>

	                    <div class="header__lang-dropdown-close js-lang-close">
	                        <svg>
	                            <use xlink:href="#sym-close-circle"></use>
	                        </svg>
	                    </div>
	                </div>
	                <div class="header__lang-overlay"></div>
	            </div>
	        </div>
	    </div>
	</div>
