<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header(); ?>
<html lang="ru" class="page-main page-tr">
<div class="content" role="main">
<div class="mp">
    <div class="mp-screen mp-screen--main js-mp-screen">
        <div class="mp-screen__img">
            <div class="mp-screen__img-big" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/main-1.jpg');" data-fadein></div>
            <div class="mp-screen__img-small" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/main-1.jpg');" data-fadein></div>
        </div>
        <div class="wrap-wide mp-screen__inner">
            <h1 class="mp-screen__title">
                <p>Муниципальное бюджетное клубное учреждение</p>
                <a title="Городской дом культуры Украина" href="https://gdkukraina.ru/">ГДК «Украина»</a>
            </h1>
            <div class="icons-block-wrapper">
                <div class="social-text">Мы в соц. сетях</div>
                <div class="social-icons">
                    <a class="vk-icon-symbol" href="https://vk.com/kinozal_dk" text="none" target="_blank" rel="noopener noreferrer"></a>
                    <a class="fb-icon-symbol" href="https://www.facebook.com/groups/mbkugdkukraina" target="_blank" rel="noopener noreferrer"></a>
                    <a class="instg-icon-symbol" href="https://www.instagram.com/dk_ukraina/" target="_blank" rel="noopener noreferrer"></a>
                    <a class="youtube-icon-symbol" href="https://www.youtube.com/ГдкУкраина" target="_blank" rel="noopener noreferrer"></a>
                </div>
            </div>
            <div class="mp-screen__bottom">
                <button class="mp-screen__btn js-mp-next">
                    <svg>
                        <use xlink:href="#sym-scroll"></use>
                    </svg>
                    <span>Scroll down</span>
                </button>
            </div>
        </div>
    </div>
    <!-- /.mp-screen -->
    <div class="mp-screen mp-screen--map">
        <div class="mp-screen__map map js-map _is-layer-1">
            <div class="mp-screen__map-inner map__inner" style="background-image: url('/upload/iblock/e20/map_00_new-_1_.png');" data-fadein>
                <div class="map__layer map__layer--1 js-map-layer" data-id="1" style="background-image: url('/upload/iblock/a7b/map_01-_1_.png');"></div>
                <div class="map__layer map__layer--2 js-map-layer" data-id="2">
                    <div class="map__mark">Владивосток</div>
                </div>
                <div class="map__layer map__layer--3 js-map-layer" data-id="3" style="background-image: url('/upload/iblock/538/Way.png');"></div>
            </div>
            <div class="mp-screen__map-inner-mobile" style="background-image: url('/upload/iblock/dbe/map_00_m-_1_.png');" data-fadein></div>
        </div>
        <div class="wrap-wide mp-screen__inner">
            <div class="mp-screen__content">
                <h2 class="mp-screen__subtitle">Мы добываем диких крабов в экологически чистых водах холодных российских морей</h2>
                <p>Отличие ГК «Русский Краб» — 100%-я ориентированность на промысел краба. Весь наш флот, производственные мощности и все наше внимание сосредоточены на работе только с этим биоресурсом.</p>
            </div>
            <div class="mp-screen__factoids js-factoids">
                <div class="factoids">
                    <div class="factoid">
                        <div class="js-map-factoid _is-active" data-id="1">
                            <b>19</b>
                            <span>судов-краболовов. Собственный промысловой флот</span>
                        </div>
                    </div>
                    <div class="factoid">
                        <div class="js-map-factoid" data-id="2">
                            <b>700</b>
                            <span>сотрудников. 80% из них – экипажи судов</span>
                        </div>
                    </div>
                    <div class="factoid">
                        <div class="js-map-factoid" data-id="3">
                            <b>12,86</b>
                            <span>тыс. тонн — наша квота на добычу крабов в Беринговом, Охотском и Японском морях</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.mp-screen__inner -->
    </div>
    <!-- /.mp-screen -->
    <div class="mp-screen mp-screen--sea">
        <div class="wrap-wide mp-screen__inner">
            <div class="mp-screen__text">
                <div class="mp-screen__title">Бережно добывая дары моря, мы делаем их гастрономической ценностью для людей, экономической — для страны</div>
                <a href="/production/" class="btn btn--high">Наша продукция</a>
            </div>
        </div>
        <!-- /.mp-screen__inner -->
        <div class="mp-screen__sea" data-fadein>
            <div class="mp-screen__sea-big" style="background-image: url('/upload/iblock/d96/sea.jpg');"></div>
            <div class="mp-screen__sea-small" style="background-image: url('/upload/iblock/c8f/sea_t.jpg');"></div>
        </div>
    </div>
    <!-- /.mp-screen -->
    <div class="mp-screen mp-screen--fleet js-mp-screen">
        <div class="wrap-wide mp-screen__inner">
            <div class="mp-screen__content">
                <h2 class="mp-screen__subtitle">Наш промысловый флот</h2>
                <!--<p>Мы — первые среди крабодобывающих компаний на Дальнем Востоке и вторые — в России.</p>-->
                <p>
                    Самый крупный среди российских крабодобывающих компаний — сегодня его составляют 19 судов.
                </p>
                <p>
                    Мы считаем важным инвестировать в обновление флота. Сегодня по заказу ГК «Русский Краб» на российских верфях строятся 10 современных и технологичных краболовов, которые выйдут на лов в течение 5 лет.
                </p>
                <p>
                    Это будут суда, спроектированные специально для эксплуатации в условиях сурового климата. Они обеспечат более высокую производительность и новый уровень безопасности и комфорта для команды.
                </p>
                <a href="/fleet/" class="btn">Флот</a>
            </div>
            <div class="mp-screen__fleet">
                <div class="tabs js-tabs" data-container="tabs1">
                    <ul>
                        <li>
                            <a href="#!" data-tab="0" class="_is-active">Действующий флот</a>
                        </li>
                        <li>
                            <a href="#!" data-tab="1" class="">Строится</a>
                        </li>
                    </ul>
                </div>
                <div class="tabs-content" id="tabs1">
                    <div class="tabs-content__item js-tab-container _is-active" data-tab="0">
                        <div class="factoids">
                            <div class="factoid">
                                <div>
                                    <b>7</b>
                                    <span>Краболовов-процессоров для переработки улова в готовую продукцию </span>
                                </div>
                                <div class="factoid__img">
                                    <div class="factoid__img-img" style="background-image: url('/upload/iblock/704/2.png');"></div>
                                </div>
                            </div>
                            <div class="factoid">
                                <div>
                                    <b>12</b>
                                    <span>
                                        Краболовов<br />
                                        для вылова и перевозки <br />
                                        живого краба
                                    </span>
                                </div>
                                <div class="factoid__img">
                                    <div class="factoid__img-img" style="background-image: url('/upload/iblock/2a3/2.png');"></div>
                                </div>
                            </div>
                        </div>
                        <div class="accordeon js-accordeon">
                            <div class="accordeon-item js-acc-item">
                                <div class="accordeon-item__title js-acc-title">
                                    <div class="accordeon-item__title-inner">Размерения</div>
                                    <button class="acc-item__icon">
                                        <span>Open text</span>
                                    </button>
                                </div>
                                <div class="accordeon-item__text js-acc-content">
                                    Суда действующего флота имеют длину от&nbsp;50&nbsp;до&nbsp;60&nbsp;метров и&nbsp;ширину от&nbsp;8&nbsp;до&nbsp;10&nbsp;метров.
                                </div>
                            </div>
                            <div class="accordeon-item js-acc-item">
                                <div class="accordeon-item__title js-acc-title">
                                    <div class="accordeon-item__title-inner">Оборудование</div>
                                    <button class="acc-item__icon">
                                        <span>Open text</span>
                                    </button>
                                </div>
                                <div class="accordeon-item__text js-acc-content">
                                    Суда для перевозки живого краба оснащены чиллерами, которые позволяют перевозить продукцию при температуре от&nbsp;0&nbsp;до&nbsp;1&deg;C.
                                </div>
                            </div>
                            <div class="accordeon-item js-acc-item">
                                <div class="accordeon-item__title js-acc-title">
                                    <div class="accordeon-item__title-inner">Производительность</div>
                                    <button class="acc-item__icon">
                                        <span>Open text</span>
                                    </button>
                                </div>
                                <div class="accordeon-item__text js-acc-content">
                                    Мощность фабрик на&nbsp;процессорах позволяет выпускать от&nbsp;10&nbsp;до&nbsp;15&nbsp;тонн готовой продукции в&nbsp;сутки.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tabs-content__item js-tab-container" data-tab="1">
                        <div class="factoids">
                            <div class="factoid">
                                <div>
                                    <b>3</b>
                                    <span>Процессора с фабрикой по переработке краба</span>
                                </div>
                                <div class="factoid__img">
                                    <div class="factoid__img-img" style="background-image: url('/upload/iblock/658/1.png');"></div>
                                </div>
                            </div>
                            <div class="factoid">
                                <div>
                                    <b>7</b>
                                    <span>Краболовов для добычи и перевозки живого краба</span>
                                </div>
                                <div class="factoid__img">
                                    <div class="factoid__img-img" style="background-image: url('/upload/iblock/64b/1.png');"></div>
                                </div>
                            </div>
                        </div>
                        <div class="accordeon js-accordeon">
                            <div class="accordeon-item js-acc-item">
                                <div class="accordeon-item__title js-acc-title">
                                    <div class="accordeon-item__title-inner">Размерения</div>
                                    <button class="acc-item__icon">
                                        <span>Open text</span>
                                    </button>
                                </div>
                                <div class="accordeon-item__text js-acc-content">
                                    Основные размерения судов нового флота: длина&nbsp;&mdash; 57,70&nbsp;м, ширина&nbsp;&mdash; 12,60&nbsp;м
                                </div>
                            </div>
                            <div class="accordeon-item js-acc-item">
                                <div class="accordeon-item__title js-acc-title">
                                    <div class="accordeon-item__title-inner">Оборудование</div>
                                    <button class="acc-item__icon">
                                        <span>Open text</span>
                                    </button>
                                </div>
                                <div class="accordeon-item__text js-acc-content">
                                    Объем танков для перевозки живого краба&nbsp;&mdash; 640 м3. Емкость по&nbsp;живому крабу 120&nbsp;тонн.
                                </div>
                            </div>
                            <div class="accordeon-item js-acc-item">
                                <div class="accordeon-item__title js-acc-title">
                                    <div class="accordeon-item__title-inner">Производительность</div>
                                    <button class="acc-item__icon">
                                        <span>Open text</span>
                                    </button>
                                </div>
                                <div class="accordeon-item__text js-acc-content">
                                    Мощность фабрик на&nbsp;процессорах&nbsp;&mdash; 15&nbsp;тонн готовой продукции в&nbsp;сутки.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.tabs-content -->
            </div>
        </div>
        <!-- /.mp-screen__inner -->
    </div>
    <!-- /.mp-screen -->
    <div class="mp-screen mp-screen--img js-mp-screen">
        <div class="mp-screen__img">
            <div class="mp-screen__img-big" style="background-image: url('/upload/iblock/161/RusCrab_IMG_-_1_.jpg');" data-fadein></div>
            <div class="mp-screen__img-small" style="background-image: url('/upload/iblock/972/RusCrab_IMG_-_1_.jpg');" data-fadein></div>
        </div>
        <div class="wrap-wide mp-screen__inner">
            <div class="mp-screen__text">
                <div class="mp-screen__title">Мы&nbsp;открыты для сотрудничества</div>
                <p>Рады видеть в числе наших партнеров тех, кто держит курс на рост и развитие</p>
                <a href="/tenders/" class="btn btn--high">Тендеры</a>
            </div>
        </div>
    </div>
    <!-- /.mp-screen -->
    <div class="mp-screen mp-screen--news js-mp-screen">
        <div class="mp-screen__inner">
            <h2 class="mp-screen__subtitle">Новости</h2>
            <div class="news">
                <div class="news-item">
                    <a href="/news/sotrudniki-gk-russkiy-krab-ochistili-ot-musora-poberezhe-amurskogo-zaliva/" class="news-item__link">
                        <div class="news-item__date">21 сентября 2021</div>
                        <h3 class="news-item__title">Сотрудники ГК "Русский Краб" очистили от мусора побережье Амурского залива</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/4af/EFR_2981.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/na-onezhskom-sudostroitelnom-zavode-zalozhen-kil-chetvertogo-krabolova-dlya-gk-russkiy-krab/" class="news-item__link">
                        <div class="news-item__date">26 июля 2021</div>
                        <h3 class="news-item__title">На Онежском судостроительном заводе заложен киль четвертого краболова для ГК «Русский Краб»</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/5e2/504-zakladka.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/gk-russkiy-krab-soobshchaet-o-rezultatakh-proizvodstvennoy-deyatelnosti-za-i-polugodie-2021-goda-/" class="news-item__link">
                        <div class="news-item__date">14 июля 2021</div>
                        <h3 class="news-item__title">ГК «Русский Краб» сообщает о результатах производственной деятельности за I полугодие 2021 года</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/09c/6.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/sotrudniki-gk-russkiy-krab-udostoeny-otraslevykh-nagrad/" class="news-item__link">
                        <div class="news-item__date">14 июля 2021</div>
                        <h3 class="news-item__title">Сотрудники ГК «Русский Краб» удостоены отраслевых наград</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/227/Sergeev.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/proekt-stroitelstva-krabolovnogo-flota-gk-russkiy-krab-prodolzhaetsya-/" class="news-item__link">
                        <div class="news-item__date">29 июня 2021</div>
                        <h3 class="news-item__title">Проект строительства краболовного флота ГК «Русский Краб» продолжается</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/9a4/Rezka.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/v-gruppe-kompaniy-russkiy-krab-formiruyut-kollektivnyy-immunitet/" class="news-item__link">
                        <div class="news-item__date">9 июня 2021</div>
                        <h3 class="news-item__title">В группе компаний «Русский Краб» формируют коллективный иммунитет</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/1b4/pexels_photo_3985170.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="mp-screen__news-bottom">
                <a href="/news/" class="btn btn--high btn--tr">Больше новостей</a>
            </div>
        </div>
    </div>
    <!-- /.mp-screen -->
    <div class="mp-screen mp-screen--form js-mp-screen">
        <div class="mp-screen__inner">
            <form action="/ajax/callback.php?site=s1" class="form js-form js-validate-form" method="POST" novalidate autocomplete="off" data-recaptcha-key="6LdcPNwZAAAAAGeZ7oQaCU0cyjjAr6-LJlIsQEkC">
                <div class="form__inner">
                    <div class="form__title">Форма обратной связи</div>
                    <div class="form__text"></div>
                    <div class="input-wrap js-input-wrap">
                        <label for="feedback-1-name" class="form__prelabel">
                            <span>Имя</span>
                        </label>
                        <input type="text" class="input-text form__input js-input" name="name" id="feedback-1-name" maxlength="64" data-minlength="2" placeholder="Ваше имя" />
                        <label for="feedback-1-name" data-label class="form__label"></label>
                    </div>
                    <div class="input-wrap js-input-wrap">
                        <label for="feedback-name" class="form__prelabel">
                            <span>Тема обращения</span>
                        </label>
                        <div class="select select--round js-select">
                            <select name="category">
                                <option value="81" selected>Тендеры</option>
                                <option value="82">Другое</option>
                            </select>
                            <div class="select__value js-select-value">Тендеры</div>
                        </div>
                    </div>
                    <div class="input-wrap js-input-wrap">
                        <label for="feedback-1-email" class="form__prelabel">
                            <span>E-mail *</span>
                        </label>
                        <input type="email" class="input-text form__input js-input" name="email" id="feedback-1-email" maxlength="128" data-required data-email placeholder="Ваш e-mail " />
                        <label for="feedback-1-email" data-label class="form__label"></label>
                    </div>
                    <div class="input-wrap js-input-wrap">
                        <label for="feedback-1-phone" class="form__prelabel">
                            <span>Телефон *</span>
                        </label>
                        <input
                            type="tel"
                            class="input-text form__input js-input js-iti"
                            name="phone"
                            id="feedback-1-phone"
                            maxlength="18"
                            data-required
                            data-phone
                            data-preferred-countries="ru,us,jp,cn,kr,sg,tw,my"
                            data-default-country="ru"
                        />
                        <label for="feedback-1-phone" data-label class="form__label"></label>
                    </div>
                    <div class="input-wrap js-input-wrap">
                        <label for="feedback-1-comment" class="form__prelabel">
                            <span>Комментарий</span>
                        </label>
                        <input type="text" class="input-text form__input js-input" name="comment" id="feedback-1-comment" maxlength="128" placeholder="Добавьте комментарий" />
                        <label for="feedback-1-comment" data-label class="form__label"></label>
                    </div>
                    <div class="form__bottom">
                        <div class="form-agreement">
                            <div class="input-wrap">
                                <label class="form-agreement__checkbox">
                                    <input type="checkbox" name="agree" data-required data-type="checkbox" id="feedback-1-agree" />
                                    <i>
                                        <svg>
                                            <use xlink:href="#sym-checkbox"></use>
                                        </svg>
                                    </i>
                                    <span class="form-agreement__text">
                                        Отправляя эту форму, вы даете согласие на <a href="/upload/files/agreement-personal-data-processing-rus.pdf" target="blank">обработку персональных данных</a> и
                                        <a href="/upload/files/cookie_rus.pdf" target="_blank">использование файлов Cookies</a>
                                    </span>
                                </label>
                                <label for="feedback-1-agree" data-label class="form__label"></label>
                            </div>
                        </div>
                        <div class="feedback__submit-wrap">
                            <button type="submit" class="btn btn--high form__btn form__submit js-submit" data-submit disabled>Отправить</button>
                        </div>
                    </div>
                </div>
                <!-- /.form__inner -->
                <div class="form__message">
                    <div class="form__message-title js-form-message-title"></div>
                    <div class="form__message-text js-form-message-text"></div>
                    <button type="button" class="btn-round btn-round--close feedback__close js-form-ok js-close-popup">
                        <svg>
                            <use xlink:href="#sym-close"></use>
                        </svg>
                        <span>Закрыть</span>
                    </button>
                </div>
                <input type="hidden" name="g-recaptcha-response" value="" class="js-recaptcha-input" />
            </form>
        </div>
        <!-- /.fp-screen__inner -->
    </div>
    <!-- /.mp-screen -->
</div>
<!-- /.map -->
</div>
<!-- /.content -->
<?php get_footer(); ?>
