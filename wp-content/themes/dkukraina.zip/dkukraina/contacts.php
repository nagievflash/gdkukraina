<?php
/**
 * Template name: шаблон Контакты
 */

get_header(); ?>
<html lang="ru" class="page-contacts">
<div class="content" role="main">
    <div class="wrap-wide">
        <div class="contacts">
            <h1 class="contacts__title">Контакты</h1>
            <div class="contacts-item">
                <a href="mailto:office@russiancrab.ru" class="contacts-item__email">office@russiancrab.ru</a>
            </div>
            <div class="contacts-item">
                <a href="tel:+74232643737" class="contacts-item__tel">+7 (423) 264-37-37</a>
            </div>
            <div class="contacts-item">
                690066, Россия, Приморский край, г. Владивосток, ул. Шилкинская, д.7Б
            </div>
            <div class="departments">
                <div class="departments-item">
                    <div class="departments-item__title">Коммерческий департамент</div>
                    <div class="person">
                        <div class="person__img" style="background-image: url('/upload/iblock/449/YUrova.jpg');"></div>
                        <div class="person__name">Юлия Юрова</div>
                        <div class="person__desc">Начальник отдела продаж</div>
                        <div class="person__contact">
                            <a href="tel:+742326437374656">+7 (423) 264-37-37 доб. 4656</a>
                        </div>
                        <div class="person__contact">
                            <a href="mailto:Yuliya.Yurova@russiancrab.ru">Yuliya.Yurova@russiancrab.ru</a>
                        </div>
                    </div>
                    <div class="person">
                        <div class="person__img" style="background-image: url('/upload/iblock/ac2/Tyapsheva.jpg');"></div>
                        <div class="person__name">Наталья Тяпшева</div>
                        <div class="person__desc">Ведущий менеджер по продажам готовой продукции</div>
                        <div class="person__contact">
                            <a href="tel:+742326437374022">+7 (423) 264-37-37 доб. 4022</a>
                        </div>
                        <div class="person__contact">
                            <a href="mailto:Nataliya.Tyapsheva@russiancrab.ru">Nataliya.Tyapsheva@russiancrab.ru</a>
                        </div>
                    </div>
                    <div class="person">
                        <div class="person__img" style="background-image: url('/upload/iblock/f5c/Li.jpg');"></div>
                        <div class="person__name">Евгений Ли</div>
                        <div class="person__desc">Менеджер по продажам (живой краб, Ю.Корея)</div>
                        <div class="person__contact">
                            <a href="tel:+742326437374621">+7 (423) 264-37-37 доб. 4621</a>
                        </div>
                        <div class="person__contact">
                            <a href="mailto:Evgeniy.Li@russiancrab.ru">Evgeniy.Li@russiancrab.ru</a>
                        </div>
                    </div>
                    <div class="person">
                        <div class="person__img" style="background-image: url('/upload/iblock/7ca/Podlesnyi_.jpg');"></div>
                        <div class="person__name">Петр Подлесный</div>
                        <div class="person__desc">Менеджер по продажам (живой краб, Китай)</div>
                        <div class="person__contact">
                            <a href="tel:+742326437374628">+7 (423) 264-37-37 доб. 4628</a>
                        </div>
                        <div class="person__contact">
                            <a href="mailto:Petr.Podlesnyi@russiancrab.ru">Petr.Podlesnyi@russiancrab.ru</a>
                        </div>
                    </div>
                    <div class="person">
                        <div class="person__img" style="background-image: url('/upload/iblock/a78/Skvarnik-Evgeniya.jpg');"></div>
                        <div class="person__name">Евгения Скварник</div>
                        <div class="person__desc">Менеджер по продажам готовой продукции</div>
                        <div class="person__contact">
                            <a href="tel:+742326437374019">+7 (423) 264-37-37 доб. 4019</a>
                        </div>
                        <div class="person__contact">
                            <a href="mailto:Evgeniya.Skvarnik@russiancrab.ru">Evgeniya.Skvarnik@russiancrab.ru</a>
                        </div>
                    </div>
                </div>
                <div class="departments-item">
                    <div class="departments-item__title">Департамент по управлению персоналом</div>
                    <div class="person">
                        <div class="person__name">Для плавсостава</div>
                        <div class="person__desc"></div>
                        <div class="person__contact">
                            <a href="tel:+742326437374014464046704671">+7 (423) 264-37-37&nbsp;доб.&nbsp;4014, 4640, 4670, 4671</a>
                        </div>
                        <div class="person__contact">
                            <a href="mailto:rabota@russiancrab.ru">rabota@russiancrab.ru</a>
                        </div>
                    </div>
                    <div class="person">
                        <div class="person__name">
                            Для берегового персонала<br />
                            Ольга Оробченко
                        </div>
                        <div class="person__desc">Менеджер по подбору и развитию персонала</div>
                        <div class="person__contact">
                            <a href="tel:+742326437374609">+7 (423) 264-37-37&nbsp;доб.&nbsp;4609</a>
                        </div>
                        <div class="person__contact">
                            <a href="mailto:OrobchenkoOA@russiancrab.ru">OrobchenkoOA@russiancrab.ru</a>
                        </div>
                    </div>
                </div>
                <div class="departments-item">
                    <div class="departments-item__title">Отдел снабжения</div>
                    <div class="person">
                        <div class="person__img" style="background-image: url('/upload/iblock/617/kolyada-_1_.jpg');"></div>
                        <div class="person__name">Григорий Коляда</div>
                        <div class="person__desc">Начальник отдела снабжения</div>
                        <div class="person__contact">
                            <a href="tel:+742326437374613">+7 (423) 264-37-37 доб. 4613</a>
                        </div>
                        <div class="person__contact">
                            <a href="tel:+79147067935">+7 914 706-79-35</a>
                        </div>
                        <div class="person__contact">
                            <a href="mailto:Grigoriy.Kolyada@russiancrab.ru">Grigoriy.Kolyada@russiancrab.ru</a>
                        </div>
                    </div>
                </div>
                <div class="departments-item">
                    <div class="departments-item__title">Контакты для прессы</div>
                    <div class="person">
                        <div class="person__name"></div>
                        <div class="person__desc"></div>
                        <div class="person__contact">
                            <a href="tel:+742326437374015">+7 (423) 264-37-37 доб. 4015</a>
                        </div>
                        <div class="person__contact">
                            <a href="mailto:pr@russiancrab.ru">pr@russiancrab.ru</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.departments -->
        </div>
        <!-- /.contacts -->
    </div>
    <!-- /.wrap-wide -->
    <div class="contacts-map">
        <div class="contacts-map__img">
            <div class="contacts-map__img-big" style="background-image: url('/upload/iblock/8e3/map_contacts.png');" data-fadein>
                <div class="map__mark">Владивосток</div>
            </div>
            <div class="contacts-map__img-small" style="background-image: url('/upload/iblock/f40/map_contacts_mobile.png');" data-fadein></div>
        </div>
    </div>
</div>
<!-- /.content -->
<?php get_footer(); ?>
