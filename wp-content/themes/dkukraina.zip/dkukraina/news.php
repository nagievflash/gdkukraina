<?php
/**
 * Template name: шаблон Новости
 */

get_header(); ?>
<html lang="ru" class="page-news">
<div class="content" role="main">
    <div class="wrap-wide">
        <div class="wrap">
            <div class="tabs">
                <ul>
                    <li>
                        <span>Новости</span>
                    </li>
                    <li>
                        <a href="?type=137">СМИ о нас</a>
                    </li>
                </ul>
            </div>
            <h1 class="title-page">Новости</h1>
            <form action="" class="news-form js-filter" autocomplete="off" id="filter-1" data-ajax-url="/ajax/news.php?site=s1" method="GET">
                <div class="news-form__row">
                    <div class="news-form__col">
                        <div class="title-h3">Категория</div>
                        <div class="select js-select">
                            <select name="category">
                                <option value="" selected>Все</option>
                                <option value="139">Операционная деятельность</option>
                                <option value="138">Строительство нового флота</option>
                                <option value="341">Кадровые изменения</option>
                                <option value="342">События</option>
                                <option value="343">Другое</option>
                                <option value="401">COVID-19</option>
                            </select>
                            <div class="select__value js-select-value">Все</div>
                        </div>
                    </div>
                    <div class="news-form__col">
                        <div class="title-h3">Год</div>
                        <div class="select js-select">
                            <select name="year">
                                <option value="" selected>Все года</option>
                                <option value="2021">2021</option>
                                <option value="2020">2020</option>
                            </select>
                            <div class="select__value js-select-value">Все года</div>
                        </div>
                    </div>
                </div>
                <input type="hidden" name="type" value="136" />
                <input type="hidden" name="offset" value="0" class="js-input-offset" disabled />
            </form>
            <div class="news js-news">
                <div class="news-item">
                    <a href="/news/sotrudniki-gk-russkiy-krab-ochistili-ot-musora-poberezhe-amurskogo-zaliva/" class="news-item__link">
                        <div class="news-item__date">21 сентября 2021</div>
                        <h3 class="news-item__title">Сотрудники ГК "Русский Краб" очистили от мусора побережье Амурского залива</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/4af/EFR_2981.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/na-onezhskom-sudostroitelnom-zavode-zalozhen-kil-chetvertogo-krabolova-dlya-gk-russkiy-krab/" class="news-item__link">
                        <div class="news-item__date">26 июля 2021</div>
                        <h3 class="news-item__title">На Онежском судостроительном заводе заложен киль четвертого краболова для ГК «Русский Краб»</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/5e2/504-zakladka.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/gk-russkiy-krab-soobshchaet-o-rezultatakh-proizvodstvennoy-deyatelnosti-za-i-polugodie-2021-goda-/" class="news-item__link">
                        <div class="news-item__date">14 июля 2021</div>
                        <h3 class="news-item__title">ГК «Русский Краб» сообщает о результатах производственной деятельности за I полугодие 2021 года</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/09c/6.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/sotrudniki-gk-russkiy-krab-udostoeny-otraslevykh-nagrad/" class="news-item__link">
                        <div class="news-item__date">14 июля 2021</div>
                        <h3 class="news-item__title">Сотрудники ГК «Русский Краб» удостоены отраслевых наград</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/227/Sergeev.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/proekt-stroitelstva-krabolovnogo-flota-gk-russkiy-krab-prodolzhaetsya-/" class="news-item__link">
                        <div class="news-item__date">29 июня 2021</div>
                        <h3 class="news-item__title">Проект строительства краболовного флота ГК «Русский Краб» продолжается</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/9a4/Rezka.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/v-gruppe-kompaniy-russkiy-krab-formiruyut-kollektivnyy-immunitet/" class="news-item__link">
                        <div class="news-item__date">9 июня 2021</div>
                        <h3 class="news-item__title">В группе компаний «Русский Краб» формируют коллективный иммунитет</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/1b4/pexels_photo_3985170.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/v-korpus-stroyashchegosya-krabolova-gk-russkiy-krab-ustanovlen-glavnyy-dvigatel/" class="news-item__link">
                        <div class="news-item__date">28 мая 2021</div>
                        <h3 class="news-item__title">В корпус строящегося краболова ГК «Русский Краб» установлен главный двигатель</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/0fc/Dvigatel.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/kachestvo-produktsii-gk-russkiy-krab-vysoko-otsenili-v-ispanii/" class="news-item__link">
                        <div class="news-item__date">24 мая 2021</div>
                        <h3 class="news-item__title">Качество продукции ГК «Русский Краб» высоко оценили в Испании</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/f14/siniy-vm.JPG');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/komanda-gk-russkiy-krab-prinyala-uchastie-v-ekologicheskoy-aktsii/" class="news-item__link">
                        <div class="news-item__date">18 мая 2021</div>
                        <h3 class="news-item__title">Команда ГК "Русский Краб" приняла участие в экологической акции</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/23c/Green.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
                <div class="news-item">
                    <a href="/news/sayt-gk-russkiy-krab-poluchil-nagradu-tagline-awards/" class="news-item__link">
                        <div class="news-item__date">30 апреля 2021</div>
                        <h3 class="news-item__title">Сайт ГК «Русский Краб» получил награду Tagline Awards</h3>
                        <div class="news-item__img">
                            <div class="news-item__img-inner" style="background-image: url('/upload/iblock/db5/Tagline-Awards.jpg');" data-fadein></div>
                        </div>
                    </a>
                </div>
            </div>
            <button class="btn btn--high btn--tr news-more js-news-more">Больше новостей</button>
        </div>
        <!-- /.wrap -->
    </div>
    <!-- /.wrap-wide -->
</div>
<!-- /.content -->
<?php get_footer(); ?>
